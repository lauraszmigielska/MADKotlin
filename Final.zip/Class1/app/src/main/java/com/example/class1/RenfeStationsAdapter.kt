package com.example.class1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RenfeStationAdapter(private val stationList: List<Pair<String, Double>>) :
    RecyclerView.Adapter<RenfeStationAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val stationName: TextView = view.findViewById(R.id.stationName)
        val stationDistance: TextView = view.findViewById(R.id.stationDistance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_renfe_station, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val station = stationList[position]
        holder.stationName.text = station.first
        holder.stationDistance.text = "${String.format("%.2f", station.second)} km"
    }

    override fun getItemCount() = stationList.size
}
