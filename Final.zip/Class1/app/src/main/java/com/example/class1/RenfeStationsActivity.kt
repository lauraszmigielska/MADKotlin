package com.example.class1

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class RenfeStationActivity : AppCompatActivity() {
    private val TAG = "RenfeStationActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_renfe_stations)

        try {
            val stationList = intent.getSerializableExtra("stationList") as? Array<Pair<String, Double>> ?: emptyArray()

            // Debug log for received data
            stationList.forEach { station ->
                Log.d(TAG, "Station: ${station.first}, Distance: ${station.second} km")
            }

            val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = RenfeStationAdapter(stationList.toList())
        } catch (e: Exception) {
            Log.e(TAG, "Error receiving or processing station list", e)
        }
    }
}
