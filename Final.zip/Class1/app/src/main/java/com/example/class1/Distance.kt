package com.example.class1

import android.location.Location
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DistanceActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_distance)

        // Obtener los datos pasados a través del Intent
        val location = intent.getParcelableExtra<Location>("location")
        val stationName = intent.getStringExtra("stationName")
        val stationLatitude = intent.getDoubleExtra("stationLatitude", 0.0)
        val stationLongitude = intent.getDoubleExtra("stationLongitude", 0.0)

        // Calcular la distancia
        val results = FloatArray(1)
        if (location != null) {
            Location.distanceBetween(location.latitude, location.longitude, stationLatitude, stationLongitude, results)
            val distance = results[0] / 1000 // Convert to kilometers

            // Mostrar la distancia en la interfaz de usuario
            val textView = findViewById<TextView>(R.id.distanceTextView)
            textView.text = "La distancia desde tu ubicación a $stationName es de $distance km."
        }
    }
}
